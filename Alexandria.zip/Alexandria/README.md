# Alexandria
Alexandria: 📚 Sistema de gerenciamento e catalogação de livros desenvolvido em JavaScript puro (Vanilla JS). Utiliza Local Storage para persistência de dados. Permite cadastro, edição, descarte, organização por Grupos/Subgrupos e backup/restauração de dados via arquivos JSON.
